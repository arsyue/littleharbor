const MapArt=(()=>{
 const canvas=document.querySelector("#terrain"),ctx=canvas.getContext("2d");
 let w=0,h=0,density=1,latest=null,effects=[];
 const blue=new Image(),paint=[];
 function pos(t,n){
  const tight=w<640, columns=n===1?[.265]:n===2?[.23,.27]:[.32,.17,.18];
  const rows=n===1?[.55]:n===2?[.33,.72]:[.53,.235,.80];
  const x=tight?(n===3&&t.slot===0?.27:.205):columns[t.slot];
  return [t.team?1-x:x,rows[t.slot]];
 }
 function makePaint(){
  const layer=document.createElement("canvas");layer.width=blue.naturalWidth;layer.height=blue.naturalHeight;
  const c=layer.getContext("2d",{willReadFrequently:true});c.drawImage(blue,0,0);
  const pixels=c.getImageData(0,0,layer.width,layer.height),a=pixels.data;
  for(let i=0;i<a.length;i+=4){
   const r=a[i],g=a[i+1],b=a[i+2],cool=Math.min(g-r,b-r);
   if(!a[i+3]||cool<5)continue;
   const mix=Math.min(1,(cool-5)/17),l=.22*r+.58*g+.2*b;
   a[i]=r+(Math.min(255,l*1.48+9)-r)*mix;
   a[i+1]=g+(l*.81-g)*mix;a[i+2]=b+(l*.51-b)*mix;
  }
  c.putImageData(pixels,0,0);paint[0]=blue;paint[1]=layer;
  if(latest)draw(...latest,performance.now());
 }
 blue.onload=makePaint;blue.src="./tank-hd.webp";
 function resize(){
  const r=canvas.getBoundingClientRect();if(!r.width||!r.height)return;
  w=r.width;h=r.height;density=Math.min(2.5,window.devicePixelRatio||1);
  canvas.width=Math.round(w*density);canvas.height=Math.round(h*density);
 }
 function tankWidth(){return Math.min(w*(w<640?.205:.125),h*.31,w<640?100:145)}
 function glow(x,y,r,color){const grad=ctx.createRadialGradient(x,y,0,x,y,r);grad.addColorStop(0,color);grad.addColorStop(1,"transparent");ctx.fillStyle=grad;ctx.fillRect(x-r,y-r,2*r,2*r)}
 function drawTank(t,size,selected,own,now){
  const [px,py]=pos(t,size),x=px*w,y=py*h,tw=tankWidth(),th=tw*.50,dir=t.team?-1:1;
  const shot=effects.findLast(e=>e.from===t.id&&now-e.start<160);
  const recoil=shot?Math.sin(Math.PI*(now-shot.start)/160)*tw*.045:0;
  ctx.save();ctx.translate(x,y);
  if(t.hp&&(t.id===selected||t.id===own)){
   ctx.beginPath();ctx.ellipse(-dir*tw*.06,th*.28,tw*.53,th*.31,0,0,Math.PI*2);
   ctx.fillStyle=t.id===selected?"#ffe0a72b":"#9cf1fa25";ctx.fill();
   ctx.strokeStyle=t.id===selected?"#ffe7a7":"#9ae6eb";ctx.lineWidth=1.3;ctx.stroke();
  }
  ctx.scale(dir,1);ctx.translate(-recoil,0);
  if(!t.hp){ctx.globalAlpha=.7;ctx.filter="grayscale(1) brightness(.54)"}
  if(paint[t.team])ctx.drawImage(paint[t.team],-tw*.48,-th*.55,tw,th);
  if(shot&&now-shot.start<90)glow(tw*.54,-th*.19,tw*.12,"#ffe59a");
  ctx.restore();
 }
 function draw(game,selected,own,now){
  latest=[game,selected,own];if(!game||!w)return;
  ctx.setTransform(canvas.width/w,0,0,canvas.height/h,0,0);ctx.clearRect(0,0,w,h);
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality="high";
  effects=effects.filter(e=>now-e.start<650);
  game.tanks.forEach(t=>drawTank(t,game.size,selected,own,now));
  for(const e of effects){
   const a=game.tanks.find(t=>t.id===e.from),b=game.tanks.find(t=>t.id===e.to);if(!a||!b)continue;
   const aa=pos(a,game.size),bb=pos(b,game.size),f=(now-e.start)/330,tw=tankWidth();
   const x1=aa[0]*w+(a.team?-1:1)*tw*.48,y1=aa[1]*h-tw*.09,x2=bb[0]*w,y2=bb[1]*h;
   if(f>=0&&f<1){
    const x=x1+(x2-x1)*f,y=y1+(y2-y1)*f,tail=Math.max(0,f-.09);
    ctx.beginPath();ctx.moveTo(x1+(x2-x1)*tail,y1+(y2-y1)*tail);ctx.lineTo(x,y);ctx.strokeStyle="#ffd77b";ctx.lineWidth=2.6;ctx.lineCap="round";ctx.stroke();glow(x,y,7,"#fff2bb");
   }else if(f>=1){const t=Math.min(1,(f-1)/.95);ctx.save();ctx.globalAlpha=1-t;glow(x2,y2,7+tw*.22*t,"#ffcb65");ctx.strokeStyle="#fce2ac";ctx.lineWidth=2*(1-t)+.4;ctx.beginPath();ctx.arc(x2,y2,3+tw*.24*t,0,Math.PI*2);ctx.stroke();ctx.restore()}
  }
 }
 return {pos,resize,draw,animating:()=>effects.length>0,shoot:(from,to)=>effects.push({from,to,start:performance.now()})};
})();
