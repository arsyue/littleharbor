const deckShelfKey="armor-imported-decks-v1";
function readShelf(){
 try{const list=JSON.parse(localStorage.getItem(deckShelfKey)||"[]");return Array.isArray(list)?list.filter(s=>s?.id==="custom"&&typeof s.raw==="string"&&typeof s.name==="string"):[]}catch{return []}
}
function rememberDecks(list){
 const saved=readShelf();
 for(const s of list.filter(x=>x.id==="custom")){
  const index=saved.findIndex(a=>a.name===s.name);
  if(index>=0)saved.splice(index,1);
  saved.unshift(s);
 }
 if(!list.some(s=>s.id==="custom"))return true;
 try{localStorage.setItem(deckShelfKey,JSON.stringify(saved.slice(0,40)));return true}catch{return false}
}
function setupDecks(){
 if(room&&(room.phase!=="lobby"||(room.moderated&&!room.presenter))){toast("本场词表由主持人在开战前设置");return}
 const teams=room&&!room.presenter?[room.myId[0]==="A"?0:1]:[0,1];
 const shelf=readShelf(),busy=new Set();
 const initial=i=>room?(room.presenter?room.hostDecks[i]:room.ownSpec):specs[i];
 function fields(i){
  const builtins=Object.entries(PACKS).map(([k,p])=>'<option value="'+k+'">'+({valley:"入门",life:"入门",core:"中级",ielts:"进阶"}[k])+' · '+p.name+'</option>').join("");
  const saved=shelf.map((s,j)=>'<option value="s'+j+'">'+esc(s.name)+'</option>').join("");
  return '<section class="deckBlock"><label for="deck'+i+'" class="teamTitle '+(i?"orange":"blue")+'">'+names[i]+'防守词表</label><div class="deckTools"><select id="deck'+i+'">'+builtins+(saved?'<optgroup label="本机词表">'+saved+'</optgroup>':'')+'<option value="custom">自定义词表</option></select><button class="dlgBtn importBtn" id="pickFile'+i+'" type="button">导入文件</button><input type="file" id="file'+i+'" accept=".xlsx,.csv,.tsv,.txt" hidden aria-label="'+names[i]+'词表文件"></div><div class="fileInfo" id="fileInfo'+i+'" aria-live="polite"></div><div id="parts'+i+'"></div><div id="custom'+i+'" hidden><label for="name'+i+'">词表名称</label><input id="name'+i+'" maxlength="32"><label for="raw'+i+'">词条预览与编辑</label><textarea id="raw'+i+'" spellcheck="false" placeholder="river 河流&#10;cloud 云朵&#10;stone 石头&#10;forest 森林"></textarea></div>'+(i===1&&teams.length===2?'<button type="button" class="sameDeck" id="sameDeck">沿用苍蓝营词表</button>':'')+'</section>';
 }
 show(room?.presenter?"主持人 · 分配词表":"阵营词表",'<div class="importHelp">支持 Excel (.xlsx)、CSV、TSV 和 TXT。每行一组英文和中文释义。Excel 读取首张有数据的可见工作表。<a href="./word-list.csv" download="词表示例.csv">下载示例 CSV</a></div>'+teams.map(fields).join("")+'<div class="fieldError" role="alert"></div><div class="dlgActions"><button class="primary" id="saveDeck">'+(room?.presenter?"应用双方词表":room?"保存本队词表":"应用到训练")+'</button></div>',"decks");
 const rawSpec=i=>{const value=$("#deck"+i).value;return !Object.hasOwn(PACKS,value)?cleanSpec({id:"custom",name:$("#name"+i).value.trim()||"我的词表",raw:$("#raw"+i).value}):{id:value}};
 const display=(i,s,value=s.id)=>{
  $("#deck"+i).value=value;$("#custom"+i).hidden=s.id!=="custom";
  $("#name"+i).value=s.name||"我的词表";$("#raw"+i).value=s.raw||"";
 };
 for(const i of teams){
  const s=initial(i)||{id:"valley"};const match=shelf.findIndex(t=>t.name===s.name&&t.raw===s.raw);display(i,s,s.id==="custom"&&match>=0?"s"+match:s.id);
  const input=$("#file"+i),picker=$("#pickFile"+i),selector=$("#deck"+i),info=$("#fileInfo"+i),parts=$("#parts"+i),save=$("#saveDeck");
  selector.onchange=()=>{const v=selector.value,prior={id:"custom",name:$("#name"+i).value,raw:$("#raw"+i).value};
   display(i,v==="custom"?prior:v.startsWith("s")&&shelf[Number(v.slice(1))]?shelf[Number(v.slice(1))]:{id:v},v);info.textContent="";parts.replaceChildren()};
  picker.onclick=()=>input.click();
  input.onchange=async()=>{
   const file=input.files?.[0];if(!file)return;
   busy.add(i);picker.disabled=selector.disabled=save.disabled=true;info.textContent="正在读取文件…";info.classList.remove("error");
   try{
    const {words,duplicates}=await WordFiles.read(file);if(!input.isConnected)return;
    const lists=WordFiles.batches(words),stem=file.name.replace(/\.[^.]+$/,"").slice(0,24)||"我的词表";
    let start=0;const labels=lists.map(list=>{const from=start+1;start+=list.length;return "第 "+from+"–"+start+" 词"});
    const use=n=>{const part=lists[n];display(i,{id:"custom",name:stem+(lists.length>1?" · "+(n+1):""),raw:part.map(w=>w.en+"\t"+w.zh).join("\n")});info.textContent="已读取 "+words.length+" 个不同词条"+(duplicates?"，已合并 "+duplicates+" 行重复词":"")+(lists.length>1?"。本场选用 "+part.length+" 词。":"。")};
    parts.replaceChildren();
    if(lists.length>1){const select=document.createElement("select"),label=document.createElement("label");select.id="batch"+i;label.htmlFor=select.id;label.textContent="选择本场词段（每队最多 250 词）";lists.forEach((p,n)=>select.add(new Option(labels[n],String(n))));select.onchange=()=>use(+select.value);parts.append(label,select)}
    use(0);
   }catch(e){if(input.isConnected){info.textContent=e.message+" 原选择已保留。";info.classList.add("error")}}
   finally{input.value="";busy.delete(i);picker.disabled=selector.disabled=false;save.disabled=busy.size>0}
  };
 }
 const same=$("#sameDeck");if(same)same.onclick=()=>{try{const s=rawSpec(0);display(1,s);$("#parts1").replaceChildren();$("#fileInfo1").textContent="已从苍蓝营复制。"}catch(e){errBox(e)}};
 $("#saveDeck").onclick=async e=>{
  if(busy.size)return;const btn=e.currentTarget;btn.disabled=true;
  try{
   const updated=teams.map(rawSpec);
   if(room){await roomAct("deck",room.presenter?{specs:updated}:{spec:updated[0]});teams.forEach((team,n)=>specs[team]=updated[n]);}
   else specs=updated;
   const saved=rememberDecks(updated);savePrefs();
   if(room)lobby();else{resume=false;close();reset()}
   toast(saved?"词表已应用":"词表已应用，本机存储空间不足");
  }catch(e){errBox(e)}finally{btn.disabled=false}
 };
}

