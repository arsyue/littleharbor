/* The selected file stays in the browser. Only an applied match deck is sent to the room. */
const WordFiles = (() => {
  const english = new Set(["英文","英语","单词","词条","英文单词","word","words","english","term","vocabulary"]);
  const meanings = new Set(["中文","中文义","中文意思","中文释义","释义","意思","翻译","词性和中文意思","词性及释义","meaning","chinese","translation","definition"]);
  const maxBytes = 6 * 1024 * 1024;
  function columns(rows) {
    const head = rows[0].cells.map(s=>String(s||"").trim().toLowerCase().replace(/\s/g,""));
    const en = head.findIndex(x=>english.has(x)), zh = head.findIndex(x=>meanings.has(x)||x.includes("中文释义"));
    return en>=0 && zh>=0 ? {en,zh} : null;
  }
  function parseCSV(text, delimiter) {
    const rows=[]; let fields=[], value="", quoted=false, line=1, start=1;
    function finish(){fields.push(value.trim());if(fields.some(Boolean)) rows.push({line:start,cells:fields});fields=[];value="";start=line+1}
    for(let i=0;i<text.length;i++){
      const c=text[i];
      if(c==='"'){
        if(quoted&&text[i+1]==='"'){value+='"';i++}
        else if(quoted||!value.trim()){quoted=!quoted}
        else value+=c;
      } else if(c===delimiter&&!quoted){fields.push(value.trim());value=""}
      else if(c==="\n"){if(quoted)value+=" ";else finish();line++}
      else value+=c;
    }
    if(quoted)throw Error("第 "+start+" 行有未闭合的引号。");
    finish();return rows;
  }
  function textRows(text){
    text=text.replace(/^\uFEFF/,"").replace(/\r\n?/g,"\n");
    const first=text.split("\n").find(x=>x.trim())||"";
    const delimiter=["\t",",","，",";","|"].find(s=>first.includes(s));
    return delimiter?parseCSV(text,delimiter):text.split("\n").map((s,i)=>({line:i+1,cells:[s.trim()]})).filter(x=>x.cells[0]);
  }
  function parseRows(rows){
    if(!rows.length)throw Error("文件中没有词条。");
    const header=columns(rows), words=[], seen=new Set();let duplicates=0;
    for(const row of rows.slice(header?1:0)){
      const cells=row.cells;let en="",zh="";
      if(header){en=cells[header.en];zh=cells[header.zh]}
      else if(cells.length===1){
        const single=cells[0].match(/^([A-Za-z][A-Za-z’' -]*?)\s+((?:(?:n|v|vt|vi|adj|adv|prep|pron|conj|phr)\.\s*)?[\u3400-\u9fff].*)$/iu);
        if(single){en=single[1];zh=single[2]}
      }else{
        const first=/^\d+[.)、]?$/.test(cells[0])?1:0;
        en=cells[first];zh=cells.slice(first+1).filter(Boolean).join(" ");
      }
      en=norm(en);zh=String(zh||"").trim().replace(/\s+/g," ");
      if(!/^[a-z][a-z' -]*$/.test(en)||en.length>45||!/[\u3400-\u9fff]/u.test(zh)||zh.length>120)
        throw Error("第 "+row.line+" 行无法导入。请检查英文和中文释义，或参照示例 CSV。");
      if(seen.has(en)){duplicates++;continue}
      seen.add(en);words.push({en,zh});
      if(words.length>25000)throw Error("单个文件最多可导入 25,000 个词条。");
    }
    if(words.length<4)throw Error("至少需要 4 个不同的英文词条。");
    return {words,duplicates};
  }
  function decode(bytes){
    if(bytes[0]===255&&bytes[1]===254)return new TextDecoder("utf-16le").decode(bytes);
    if(bytes[0]===254&&bytes[1]===255)return new TextDecoder("utf-16be").decode(bytes);
    try{return new TextDecoder("utf-8",{fatal:true}).decode(bytes)}catch{return new TextDecoder("gb18030").decode(bytes)}
  }
  function xml(text){const doc=new DOMParser().parseFromString(text,"application/xml");if(doc.getElementsByTagName("parsererror").length)throw Error("Excel 表格的 XML 格式有误。");return doc}
  function tags(node,name){return Array.from(node.getElementsByTagNameNS("*",name))}
  function unzip(bytes){
    const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.length),u16=p=>v.getUint16(p,true),u32=p=>v.getUint32(p,true);
    let end=bytes.length-22;for(;end>=Math.max(0,bytes.length-65557);end--)if(u32(end)===0x06054b50)break;
    if(end<0||u32(end)!==0x06054b50)throw Error("请选择有效的 .xlsx 文件。");
    let p=u32(end+16);const files=new Map(),n=u16(end+10);
    if(n>5000)throw Error("工作簿太复杂，请另存为 CSV。");
    for(let i=0;i<n;i++){
      if(u32(p)!==0x02014b50)throw Error("Excel 压缩目录无效。");
      const nameLength=u16(p+28), name=new TextDecoder().decode(bytes.subarray(p+46,p+46+nameLength));
      files.set(name,{method:u16(p+10),compressed:u32(p+20),size:u32(p+24),at:u32(p+42)});
      p+=46+nameLength+u16(p+30)+u16(p+32);
    }
    let budget=20*1024*1024;
    return async name=>{
      const entry=files.get(name);if(!entry)return null;
      const {method,compressed,size,at}=entry,start=at+30+u16(at+26)+u16(at+28);
      if(size>budget||start+compressed>bytes.length)throw Error("工作表太大，请拆分或另存为 CSV。");
      budget-=size;
      const buf=bytes.slice(start,start+compressed);
      if(method===0){if(buf.length!==size)throw Error("Excel 文件大小有误。");return new TextDecoder().decode(buf)}
      if(method!==8||typeof DecompressionStream==="undefined")throw Error("此浏览器无法解压工作簿，请另存为 CSV 后导入。");
      const reader=new Blob([buf]).stream().pipeThrough(new DecompressionStream("deflate-raw")).getReader();
      const plain=new Uint8Array(size);let offset=0;
      while(true){const {done,value}=await reader.read();if(done)break;if(offset+value.length>size){await reader.cancel();throw Error("Excel 文件大小有误。")}plain.set(value,offset);offset+=value.length}
      if(offset!==size)throw Error("Excel 文件不完整。");return new TextDecoder().decode(plain);
    };
  }
  async function workbookRows(bytes){
    const read=unzip(bytes),work=await read("xl/workbook.xml"),rels=await read("xl/_rels/workbook.xml.rels");
    if(!work||!rels)throw Error("找不到 Excel 工作表。");
    const links=tags(xml(rels),"Relationship");
    const strings=await read("xl/sharedStrings.xml");
    const shared=strings?tags(xml(strings),"si").map(n=>tags(n,"t").map(t=>t.textContent).join("")):[];
    for(const sheet of tags(xml(work),"sheet")){
      if(sheet.getAttribute("state")==="hidden"||sheet.getAttribute("state")==="veryHidden")continue;
      const id=sheet.getAttribute("r:id")||sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id");
      const target=links.find(l=>l.getAttribute("Id")===id&&l.getAttribute("Type")?.endsWith("/worksheet"))?.getAttribute("Target");
      if(!target)continue;
      const path=new URL(target,"https://workbook.invalid/xl/workbook.xml").pathname.slice(1);
      const content=await read(path);if(!content)continue;
      const rows=[];
      for(const row of tags(xml(content),"row")){
        const cells=[];
        for(const cell of tags(row,"c")){
          const letters=cell.getAttribute("r")?.match(/^[A-Z]+/i)?.[0];
          let col=letters?[...letters].reduce((n,c)=>n*26+c.toUpperCase().charCodeAt(0)-64,0)-1:cells.length;
          if(col>255)continue;
          const val=tags(cell,"v")[0]?.textContent||"",type=cell.getAttribute("t");
          cells[col]=String(type==="s"?shared[Number(val)]||"":type==="inlineStr"?tags(cell,"t").map(n=>n.textContent).join(""):val).trim();
        }
        if(cells.some(Boolean))rows.push({line:Number(row.getAttribute("r"))||rows.length+1,cells:Array.from(cells,x=>x||"")});
      }
      if(rows.length)return rows;
    }
    throw Error("没有找到含词条的可见工作表。");
  }
  async function read(file){
    if(file.size>maxBytes)throw Error("文件超过 6 MB，请拆分后导入。");
    const bytes=new Uint8Array(await file.arrayBuffer());
    const ext=file.name.split(".").at(-1).toLowerCase();
    if(!["xlsx","csv","tsv","txt"].includes(ext))throw Error("请选择 XLSX、CSV、TSV 或 TXT 文件。");
    try{return parseRows(ext==="xlsx"?await workbookRows(bytes):textRows(decode(bytes)))}catch(e){if(e instanceof RangeError)throw Error("文件不完整，请重新导出。");throw e}
  }
  function batches(words){
    const out=[];for(let i=0;i<words.length;){let count=Math.min(250,words.length-i);const tail=words.length-i-count;if(tail>0&&tail<4)count-=4-tail;out.push(words.slice(i,i+count));i+=count}return out;
  }
  return {read,batches};
})();

