@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 词甲战线 · 局域网版
echo 请保持本窗口开启。学生在同一网络打开下方的局域网地址。
"%~dp0runtime\node.exe" "%~dp0server.mjs" --open
pause

