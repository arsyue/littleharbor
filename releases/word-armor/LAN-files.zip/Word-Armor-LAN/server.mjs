import { createServer } from "node:http";
import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join, resolve, dirname } from "node:path";
import { networkInterfaces } from "node:os";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { newRoom, randomCode, state, stepRoom } from "./game.mjs";

const root = dirname(fileURLToPath(import.meta.url));
const settings = JSON.parse(readFileSync(join(root, "edition.json"), "utf8"));
const lan = settings.mode === "lan";
const prefix = "/" + (process.env.BASE_PATH || "").split("/").filter(Boolean).join("/");
const basePath = prefix === "/" ? "/" : prefix + "/";
const publicOrigin = process.env.PUBLIC_ORIGIN ? new URL(process.env.PUBLIC_ORIGIN).origin : null;
const dataDir = resolve(root, process.env.DATA_DIR || "data");
mkdirSync(dataDir, { recursive: true });
const db = new DatabaseSync(join(dataDir, "rooms.sqlite"));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=4000;
CREATE TABLE IF NOT EXISTS rooms(code TEXT PRIMARY KEY, data TEXT NOT NULL, revision INTEGER NOT NULL, touched INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS rooms_touched ON rooms(touched);`);
const insert = db.prepare("INSERT OR IGNORE INTO rooms VALUES(?,?,0,?)");
const find = db.prepare("SELECT * FROM rooms WHERE code=?");
const write = db.prepare("UPDATE rooms SET data=?,revision=revision+1,touched=? WHERE code=?");
const touch = db.prepare("UPDATE rooms SET touched=? WHERE code=?");
const clean = db.prepare("DELETE FROM rooms WHERE touched < ?");
const ttl = 24 * 60 * 60 * 1000;
const types = { "index.html":"text/html", "style.css":"text/css", "icon.svg":"image/svg+xml",
  "app.js":"text/javascript", "engine.js":"text/javascript", "art.js":"text/javascript" };
const assets = new Map(Object.entries(types).map(([file, type]) =>
  [file, { type, bytes:readFileSync(join(root, "public", file)) }]));

function fail(status, message) {
  return Object.assign(new Error(message), { status });
}
function json(res, status, data) {
  res.writeHead(status, { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store" });
  res.end(JSON.stringify(data));
}
async function readBody(req) {
  const chunks = [];
  let count = 0;
  for await (const chunk of req.iterator({ destroyOnReturn:false })) {
    count += chunk.length;
    if (count > 32768) { req.resume(); throw fail(413, "词表过大。"); }
    chunks.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
    if (value && typeof value === "object" && !Array.isArray(value)) return value;
  } catch {}
  throw fail(400, "请提交有效的房间数据。");
}
function changeRoom(code, action, key, body) {
  const now = Date.now();
  if (!code) {
    const token = randomUUID();
    for (let i = 0; i < 6; i++) {
      const id = randomCode();
      const room = newRoom(id, body, token);
      if (insert.run(id, JSON.stringify(room), now).changes)
        return { ...state(room, token, 0), token };
    }
    throw fail(503, "请重新创建房间。");
  }
  const row = find.get(code);
  if (!row || now - row.touched >= ttl) throw fail(404, "房间不存在或已过期。");
  const room = JSON.parse(row.data);
  const result = stepRoom(room, key, action, body, now);
  if (result.changed) write.run(JSON.stringify(room), now, code);
  else if (now - row.touched > 60000) touch.run(now, code);
  return { ...state(room, result.key, row.revision + Number(result.changed)), ...result.extra };
}
function api(req, res, route, body) {
  const create = route === "api/rooms";
  const match = /^api\/rooms\/([A-Z2-9]{6})(?:\/(join|deck|start|attack|leave|switch|rules))?$/.exec(route);
  if (!create && !match) throw fail(404, "房间地址无效。");
  const action = match?.[2];
  if (req.method !== (create || action ? "POST" : "GET")) throw fail(405, "请求方式无效。");
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = changeRoom(match?.[1], action, req.headers["x-player"] || "", body);
    db.exec("COMMIT");
    json(res, 200, result);
  } catch (error) { if (db.isTransaction) db.exec("ROLLBACK"); throw error; }
}
function addresses() {
  return Object.values(networkInterfaces()).flat().filter(a => a && a.family === "IPv4" && !a.internal)
    .map(a => a.address).sort((a,b) => rank(b) - rank(a));
}
function rank(ip) {
  if (ip.startsWith("192.168.")) return 3;
  if (ip.startsWith("10.")) return 2;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(ip)) return 1;
  return 0;
}
function validOrigin(req) {
  if (!req.headers.origin) return true;
  try {
    const origin = new URL(req.headers.origin);
    return publicOrigin ? origin.origin === publicOrigin
      : ["http:", "https:"].includes(origin.protocol) && origin.host === req.headers.host;
  } catch { return false; }
}
const server = createServer({requestTimeout:20000, headersTimeout:15000}, async (req,res) => {
  try {
    const path = new URL(req.url, "http://local.invalid").pathname;
    if (prefix !== "/" && path === prefix) { res.writeHead(308,{Location:basePath}); res.end(); return; }
    if (!path.startsWith(basePath)) throw fail(404, "页面不存在。");
    const route = path.slice(basePath.length);
    if (route.startsWith("api/")) {
      if (req.method === "POST" && !validOrigin(req)) throw fail(403, "请求来源无效。");
      const body = req.method === "POST" ? await readBody(req) : {};
      api(req, res, route, body);
      return;
    }
    if (!["GET","HEAD"].includes(req.method)) throw fail(405,"请求方式无效。");
    if (route === "healthz") { json(res,200,{ok:true,edition:settings.mode}); return; }
    if (route === "local-invite") {
      const loopback = ["127.0.0.1","::1","::ffff:127.0.0.1"].includes(req.socket.remoteAddress);
      const addr = lan && loopback && addresses()[0];
      const origin = publicOrigin || (addr ? "http://"+addr+":"+server.address().port : null);
      json(res,200,{origin:origin ? origin+basePath : null}); return;
    }
    const asset = assets.get(route || "index.html");
    if (!asset) throw fail(404, "页面不存在。");
    res.writeHead(200,{"Content-Type":asset.type+"; charset=utf-8","Cache-Control":"no-cache","X-Content-Type-Options":"nosniff"});
    res.end(req.method === "HEAD" ? undefined : asset.bytes);
  } catch (error) {
    if (error.code?.startsWith("ERR_SQLITE") || error.code?.startsWith("SQLITE")) {
      console.error("Database error",error.message);
      json(res,503,{error:"房间数据暂时无法读取，请稍后重试。"});
    } else json(res,error.status || 400,{error:error.message || "操作失败。"});
  }
});
clean.run(Date.now()-ttl);
setInterval(()=>clean.run(Date.now()-ttl),3600000).unref();
const preferred = Number(process.env.PORT || settings.port);
let port = preferred;
const bind = process.env.HOST || "0.0.0.0";
server.on("error", error => {
  if (lan && error.code === "EADDRINUSE" && port < preferred+20) { server.listen(++port,bind); return; }
  console.error(error.message); process.exitCode=1;
});
server.on("listening", () => {
  const actual = server.address().port;
  const local = "http://127.0.0.1:"+actual+basePath;
  console.log("本机游戏地址  "+local);
  if (lan) for (const ip of addresses()) console.log("同一局域网游戏地址  http://"+ip+":"+actual+basePath);
  if (publicOrigin) console.log("正式服游戏地址  "+publicOrigin+basePath);
  if (lan && process.argv.includes("--open") && process.platform === "win32")
    spawn("rundll32.exe",["url.dll,FileProtocolHandler",local],{detached:true,stdio:"ignore",windowsHide:true}).unref();
});
for (const signal of ["SIGINT","SIGTERM"]) process.on(signal,()=>server.close(()=>{db.close(); process.exit(0)}));
server.listen(port,bind);
